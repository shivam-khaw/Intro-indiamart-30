<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
  <link rel="stylesheet" href="{{asset('admin_assets/admin_css_js/app.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/admin_css_js/style.css')}}">
  <link rel="stylesheet" href="css/style.css">
  
  <title>Login Form</title>
  <style>
  
    </style>
</head>
<body>
   <!-- for header part -->
   <header>

<div class="logosec">
    <div class="logo">
    <img src="img/hub-logo.png" class="icn menuicn" id="menuicn" alt="menu-icon">
</div>
</div>

<!--<div class="searchbar">
    <input type="text" placeholder="Search">
    <div class="searchbtn">
        <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210180758/Untitled-design-(28).png" class="icn srchicn" alt="search-icon">
    </div>
</div>

<div class="message">
    <div class="dp">
        <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210180014/profile-removebg-preview.png" class="dpicn" alt="dp">
    </div>
</div>-->

</header>
@section('container')
 @show

</body>
</html>
